﻿using System;
using System.Collections.Generic;

namespace PersonalWork.Infrastructure.DevDB;

public partial class Table1
{
    public string? Num { get; set; }

    public string? Val { get; set; }
}
