﻿using System;
using System.Collections.Generic;

namespace PersonalWork.Infrastructure.DevDB;

public partial class Tempprice
{
    public long? ItemNumber { get; set; }

    public decimal? Sprice { get; set; }
}
